import discord
from discord.ext import commands
import random
import os
 

os.system('cls')
token = input("Enter Token: ")
client = commands.Bot(command_prefix=commands.when_mentioned_or("$"))
os.system('cls')
os.system(f'title [SPANISH AFK CHECKER]')
os.system(f'mode 60,20')
 
a = 'uno'
b = 'dos'
c = 'tres'
d = 'cuatro'
e = 'cinco'
f = 'seis'
g = 'siete'
h = 'ocho'
i = 'nueve'
j = 'diez'
k = 'once'
l = 'doce'
m = 'trece'
n = 'catorce'
o = 'quince'
p = 'dieciséis'
q = 'diecisiete'
r = 'dieciocho'
s = 'diecinueve'
t = 'veinte'
u = 'veintiuno'
v = 'veintidós'
w = 'veintitrés'
x = 'veinticuatro'
y = 'veinticinco'
z =  'veintiséis'
aa = 'veintisiete'
bb = 'veintiocho'
cc = 'veintinueve'
dd = 'treinta'
ee = 'treinta y uno'
ff = 'treinta y dos'
gg = 'treinta y tres'
hh = 'treinta y cuatro'
ii = 'treinta y cinco'
jj = 'treinta y seis'
kk = 'treinta y siete'
ll = 'treinta y ocho'
mm = 'treinta y nueve'
nn = 'cuarenta'
oo = 'cuarenta y uno'
pp = 'cuarenta y dos'
qq = 'cuarenta y tres'
rr = 'cuarenta y cuatro'
ss = 'cuarenta y cinco'
tt = 'cuarenta y seis'
uu = 'cuarenta y siete'
vv = 'cuarenta y ocho'
ww = 'cuarenta y nueve'
xx = 'cincuenta'
yy = 'cincuenta y uno'
zz = 'cincuenta y dos'
aaa = 'cincuenta y tres'
bbb = 'cincuenta y cuatro'
ccc = 'cincuenta y cinco'
ddd = 'cincuenta y seis'
eee = 'cincuenta y siete'
fff = 'cincuenta y ocho'
ggg = 'cincuenta y nueve'
hhh = 'sesenta'
iii = 'sesenta y uno'
jjj = 'sesenta y dos'
kkk = 'sesenta y tres'
lll = 'sesenta y cuatro'
mmm = 'sesenta y cinco'
nnn = 'sesenta y seis'
ooo = 'sesenta y siete'
ppp = 'sesenta y ocho'
qqq = 'sesenta y nueve'
rrr = 'setenta'
sss = 'setenta y uno'
ttt = 'setenta y dos'
vvv = 'setenta y tres'
www = 'setenta y cuatro'
xxx = 'setenta y cinco'
yyy = 'setenta y seis'
zzz = 'setenta y siete'
aaaa = 'setenta y ocho' 
bbbb = 'setenta y nueve'
cccc = 'ochenta'
dddd = 'ochenta y uno'
eeee = 'ochenta y dos'
ffff = 'ochenta y tres'
gggg = 'ochenta y cuatro'
hhhh = 'ochenta y cinco'
iiii = 'ochenta y seis'
jjjj = 'ochenta y siete'
kkkk = 'ochenta y ocho'
llll = 'ochenta y nueve'
mmmm = 'noventa'
nnnn = 'noventa y uno'
oooo = 'noventa y dos'
pppp = 'noventa y tres'
qqqq = 'noventa y cuatro'
rrrr = 'noventa y cinco'
ssss = 'noventa y seis'
tttt = 'noventa y siete'
uuuu = 'noventa y ocho'
vvvv = 'noventa y nueve'
wwww = 'cien'
@client.event
async def on_ready():
  print(f""" \u001b[31m
 ---------------------------------------------------------------------------
  say "afk check and tag the person you're checking" to start the checker 
╔═══════════════════════════════════════════════════════════════════════════
╔═══╗                   ╔╗      ╔═══╗ ╔═╗╔╗      ╔═══╗╔╗          ╔╗         
║╔═╗║                   ║║      ║╔═╗║ ║╔╝║║      ║╔═╗║║║          ║║         
║╚══╗╔══╗╔══╗ ╔═╗ ╔╗╔══╗║╚═╗    ║║ ║║╔╝╚╗║║╔╗    ║║ ╚╝║╚═╗╔══╗╔══╗║║╔╗╔══╗╔═╗
╚══╗║║╔╗║╚ ╗║ ║╔╗╗╠╣║══╣║╔╗║    ║╚═╝║╚╗╔╝║╚╝╝    ║║ ╔╗║╔╗║║╔╗║║╔═╝║╚╝╝║╔╗║║╔╝
║╚═╝║║╚╝║║╚╝╚╗║║║║║║╠══║║║║║    ║╔═╗║ ║║ ║╔╗╗    ║╚═╝║║║║║║║═╣║╚═╗║╔╗╗║║═╣║║ 
╚═══╝║╔═╝╚═══╝╚╝╚╝╚╝╚══╝╚╝╚╝    ╚╝ ╚╝ ╚╝ ╚╝╚╝    ╚═══╝╚╝╚╝╚══╝╚══╝╚╝╚╝╚══╝╚╝ 
     ║║                                                                      
     ╚╝                                                                                                               
╚═══════════════════════════════════════════════════════════════════════════
 Spanish AFK Checker Made by blood#4719
----------------------------------------------------------------------------
""")
 
@client.event
async def on_message(message):
    channel = message.channel
    if message.content.startswith('afk check'):
        await message.channel.send(a)
        await message.channel.send(b)
        await message.channel.send(c)
        await message.channel.send(d)
        await message.channel.send(e)
        await message.channel.send(f)
        await message.channel.send(g)
        await message.channel.send(h)
        await message.channel.send(i)
        await message.channel.send(j)  
        await message.channel.send(k)  
        await message.channel.send(l)  
        await message.channel.send(m)  
        await message.channel.send(n)  
        await message.channel.send(o) 
        await message.channel.send(p)
        await message.channel.send(q) 
        await message.channel.send(r)
        await message.channel.send(s)
        await message.channel.send(t)  
        await message.channel.send(u)
        await message.channel.send(v)
        await message.channel.send(w)  
        await message.channel.send(x)
        await message.channel.send(y)
        await message.channel.send(z)
        await message.channel.send(aa)
        await message.channel.send(bb)
        await message.channel.send(cc)
        await message.channel.send(dd)
        await message.channel.send(ee)
        await message.channel.send(ff)
        await message.channel.send(gg)
        await message.channel.send(hh)
        await message.channel.send(ii)
        await message.channel.send(jj)  
        await message.channel.send(kk)  
        await message.channel.send(ll)  
        await message.channel.send(mm)  
        await message.channel.send(nn)  
        await message.channel.send(oo) 
        await message.channel.send(pp)
        await message.channel.send(qq)  
        await message.channel.send(rr)
        await message.channel.send(ss)
        await message.channel.send(tt)  
        await message.channel.send(uu)
        await message.channel.send(vv)
        await message.channel.send(ww)  
        await message.channel.send(xx)
        await message.channel.send(yy)
        await message.channel.send(zz)
        await message.channel.send(aaa)
        await message.channel.send(bbb)
        await message.channel.send(ccc)
        await message.channel.send(ddd)
        await message.channel.send(eee)
        await message.channel.send(fff)
        await message.channel.send(ggg)
        await message.channel.send(hhh)
        await message.channel.send(iii)
        await message.channel.send(jjj)  
        await message.channel.send(kkk)  
        await message.channel.send(lll)  
        await message.channel.send(mmm)  
        await message.channel.send(nnn)  
        await message.channel.send(ooo) 
        await message.channel.send(ppp)
        await message.channel.send(qqq)  
        await message.channel.send(rrr)
        await message.channel.send(sss)
        await message.channel.send(ttt)  
        await message.channel.send(vvv)
        await message.channel.send(www)  
        await message.channel.send(xxx)
        await message.channel.send(yyy)
        await message.channel.send(zzz)
        await message.channel.send(aaaa)
        await message.channel.send(bbbb)
        await message.channel.send(cccc)
        await message.channel.send(dddd)
        await message.channel.send(eeee)
        await message.channel.send(ffff)
        await message.channel.send(gggg)
        await message.channel.send(hhhh)
        await message.channel.send(iiii)
        await message.channel.send(jjjj)  
        await message.channel.send(kkkk)  
        await message.channel.send(llll)  
        await message.channel.send(mmmm)  
        await message.channel.send(nnnn)  
        await message.channel.send(oooo) 
        await message.channel.send(pppp)
        await message.channel.send(qqqq)  
        await message.channel.send(rrrr)
        await message.channel.send(ssss)
        await message.channel.send(tttt)  
        await message.channel.send(uuuu)
        await message.channel.send(vvvv)
        await message.channel.send(wwww) 


client.run(token, bot=False)
