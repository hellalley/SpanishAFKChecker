# Xlyrus-Checker-OPEN-SOURCE-
# To run it say "afk check" then mention the person your afk checking.
# This is for you stamina packer nerds.
